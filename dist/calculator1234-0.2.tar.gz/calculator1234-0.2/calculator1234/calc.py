def plus(a,b):
    return a + b

def minus(a,b):
    return a - b

def mult(a,b):
    return a * b

def podel(a,b):
    return a / b

def pow(a,b):
    return a ** b

def sqrt(a):
    return a ** 0.5